package com.faker.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang.time.DateUtils;

import com.faker.bean.AdherenceScore;
import com.faker.bean.DrugDetail;
import com.faker.bean.NDC;
import com.faker.bean.Patient;
import com.faker.bean.Pharmacy;
import com.faker.bean.Prescriber;
import com.faker.bean.Prescription;
import com.mysql.jdbc.exceptions.jdbc4.CommunicationsException;

public class MySQLAccess {

	public Connection getConnection() throws SQLException {
		int count = 0;
		Connection connect = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/logstash?" + "user=root&password=password");
		} catch (CommunicationsException e) {
			if (count < 5) {
				connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/logstash?" + "user=root&password=password");
				count++;
			}
		} 
		return connect;
	}


	public String getMaxPatientId() throws SQLException {
		String maxId="0";
		Connection connect = getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement = connect.prepareStatement("SELECT max(cast(patient_id as UNSIGNED)) as patient_id from logstash.patient_info");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				maxId = resultSet.getString("patient_id") == null ? "0" : resultSet.getString("patient_id");
				
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null) {
				resultSet.close();
			}
			if (preparedStatement != null) {
			    preparedStatement.close();
			}
			if (connect != null) {
				connect.close();
			}
		}
		return maxId;
	}

	public String getMaxPresecriberId() throws SQLException {

		String maxId="0";
		Connection connect = getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement = connect.prepareStatement("SELECT max(cast(prescriber_id as UNSIGNED)) as prescriber_id from logstash.prescriber_info");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				maxId = resultSet.getString("prescriber_id") == null ? "0" : resultSet.getString("prescriber_id");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null) {
				resultSet.close();
			}
			if (preparedStatement != null) {
			    preparedStatement.close();
			}
			if (connect != null) {
				connect.close();
			}
		}
		return maxId;
	}

	public String getMaxPharmacyId() throws SQLException {

		String maxId="0";
		Connection connect = getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement = connect.prepareStatement("SELECT max(cast(pharmacy_id as UNSIGNED)) as pharmacy_id from logstash.pharmacy_info");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				maxId = resultSet.getString("pharmacy_id") == null ? "0" : resultSet.getString("pharmacy_id");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null) {
				resultSet.close();
			}
			if (preparedStatement != null) {
			    preparedStatement.close();
			}
			if (connect != null) {
				connect.close();
			}
		}
		return maxId;
	} 

	public String getMaxPriscriptionId() throws SQLException {

		String maxId="0";
		Connection connect = getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement = connect.prepareStatement("SELECT max(cast(Rx_number as UNSIGNED)) as Rx_number from logstash.prescription");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				maxId = resultSet.getString("Rx_number") == null ? "0" : resultSet.getString("Rx_number");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null) {
				resultSet.close();
			}
			if (preparedStatement != null) {
			    preparedStatement.close();
			}
			if (connect != null) {
				connect.close();
			}
		}
		return maxId;
	} 
	
	public Patient getPatient(String patientId) throws SQLException {
		Connection connect = getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Patient patient = new Patient();
		
		try {
			preparedStatement = connect.prepareStatement("SELECT  patient_id, Name, Age, Gender, Address_Line1, Address_Line2,"
					+ "City, State, country, ZipCode, latitude, longitude "
					+ "from logstash.patient_info where patient_id = "+patientId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				patient.setPatientId(resultSet.getString("patient_id"));
				patient.setName(resultSet.getString("Name"));
				patient.setAge(resultSet.getString("Age"));
				patient.setGender(resultSet.getString("Gender"));
				patient.setAddressLine1(resultSet.getString("Address_Line1"));
				patient.setAddressLine2(resultSet.getString("Address_Line2"));
				patient.setCity(resultSet.getString("City"));
				patient.setState(resultSet.getString("State"));
				patient.setCountry(resultSet.getString("country"));
				patient.setZipCode(resultSet.getString("ZipCode"));
				patient.setLatitude(resultSet.getString("latitude"));
				patient.setLongitude(resultSet.getString("longitude"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null) {
				resultSet.close();
			}
			if (preparedStatement != null) {
			    preparedStatement.close();
			}
			if (connect != null) {
				connect.close();
			}
		}
		return patient;
	}

	public Prescriber getPrescriber(String prescriberId) throws SQLException {
		Connection connect = getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Prescriber prescriber = new Prescriber();
		
		try {
			preparedStatement = connect.prepareStatement("SELECT  prescriber_id, Name, Age, Gender, Address_Line1, Address_Line2,"
					+ "City, State, country, ZipCode, latitude, longitude "
					+ "from logstash.prescriber_info where prescriber_id = " +prescriberId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				prescriber.setPrescriberId(resultSet.getString("prescriber_id"));
				prescriber.setName(resultSet.getString("Name"));
				prescriber.setAge(resultSet.getString("Age"));
				prescriber.setGender(resultSet.getString("Gender"));
				prescriber.setAddressLine1(resultSet.getString("Address_Line1"));
				prescriber.setAddressLine2(resultSet.getString("Address_Line2"));
				prescriber.setCity(resultSet.getString("City"));
				prescriber.setState(resultSet.getString("State"));
				prescriber.setCountry(resultSet.getString("country"));
				prescriber.setZipCode(resultSet.getString("ZipCode"));
				prescriber.setLatitude(resultSet.getString("latitude"));
				prescriber.setLongitude(resultSet.getString("longitude"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null) {
				resultSet.close();
			}
			if (preparedStatement != null) {
			    preparedStatement.close();
			}
			if (connect != null) {
				connect.close();
			}
		}
		return prescriber;
	}
	public List<AdherenceScore> getAdherenceScore(String patientId, String drugId, Date lastFillDate, String daysSupply) throws SQLException {
		List<AdherenceScore> adherenceScores = new ArrayList<AdherenceScore>();
		if (lastFillDate == null) {
			return adherenceScores;
		}
		Date shoulBeRefilledOn = DateUtils.addDays(lastFillDate, Integer.valueOf(daysSupply).intValue());
		Calendar cal = Calendar.getInstance();
		cal.setTime(shoulBeRefilledOn);
		String year = String.valueOf(cal.get(Calendar.YEAR)).toString();
		String month = String.valueOf(cal.get(Calendar.MONTH)).toString();
		Connection connect = getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connect.prepareStatement("SELECT patient_id,DRUG_ID,adherence_score,year,month "
					+ "FROM logstash.patient_adherence_score where patient_id = "+patientId+" and DRUG_ID = "+drugId+" and year = "+year+" and month ="+month);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				AdherenceScore adherenceScore = new AdherenceScore();
				adherenceScore.setAdherenceScore(resultSet.getString("adherence_score"));
				adherenceScore.setDrugId(resultSet.getString("DRUG_ID"));
				adherenceScore.setPatientId(resultSet.getString("patient_id"));
				adherenceScore.setYear(resultSet.getString("year"));
				adherenceScore.setMonth(resultSet.getString("month"));
				adherenceScores.add(adherenceScore);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null) {
				resultSet.close();
			}
			if (preparedStatement != null) {
			    preparedStatement.close();
			}
			if (connect != null) {
				connect.close();
			}
		}
		return adherenceScores;
	}
	public NDC getNdc(String patientDrugId) throws SQLException {
		Connection connect = getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		NDC ndc = new NDC();
		List<DrugDetail> drugDetailList = new ArrayList<DrugDetail>();
		
		
		try {
			preparedStatement = connect.prepareStatement("select a.Patient_drug_id,a.prescription_id,a.patient_id,"
					+ "b.drug_id,b.drug_name,b.drug_type,b.route "
					+ "from patient_drug_detail a join drug_detail b on a.drug_id = b.drug_id where a.Patient_drug_id ="+patientDrugId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				DrugDetail drugDetail = new DrugDetail();
				if (ndc.getPatientID() == null || ndc.getPatientID().equals("")) {
					ndc.setPatientDrugId(resultSet.getString("Patient_drug_id"));
					ndc.setPatientID(resultSet.getString("patient_id"));
					ndc.setPrescriptionId(resultSet.getString("prescription_id"));
				}
				drugDetail.setDrugId(resultSet.getString("drug_id"));
				drugDetail.setDrugName(resultSet.getString("drug_name"));
				drugDetail.setDrugType(resultSet.getString("drug_type"));
				drugDetail.setRoute(resultSet.getString("route"));
				
				drugDetailList.add(drugDetail);
			}
			ndc.setDrugDetail(drugDetailList);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null) {
				resultSet.close();
			}
			if (preparedStatement != null) {
			    preparedStatement.close();
			}
			if (connect != null) {
				connect.close();
			}
		}
		return ndc;
	}
	
	public List<DrugDetail> getDrug(int drugListSize) throws SQLException {
		Connection connect = getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<DrugDetail> drugDetailList = new ArrayList<DrugDetail>();
		Random rand = new Random();
		
		try {
			for (int i=0; i < drugListSize ; i++) {
				String randowDrugID = Integer.valueOf(rand.nextInt((9000 - 1) + 1) + 1).toString();
			preparedStatement = connect.prepareStatement("select drug_id,drug_name,drug_type,route from drug_detail where drug_id = "+randowDrugID);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				DrugDetail drugDetail = new DrugDetail();
				drugDetail.setDrugId(resultSet.getString("drug_id"));
				drugDetail.setDrugName(resultSet.getString("drug_name"));
				drugDetail.setDrugType(resultSet.getString("drug_type"));
				drugDetail.setRoute(resultSet.getString("route"));
				
				drugDetailList.add(drugDetail);
				
			}
			if (resultSet != null) {
				resultSet.close();
			}
			if (preparedStatement != null) {
			    preparedStatement.close();
			}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			if (connect != null) {
				connect.close();
			}
		}
		return drugDetailList;
	}

	public Pharmacy getPharmacy(String pharmacyId) throws SQLException {
		Connection connect = getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Pharmacy pharmacy = new Pharmacy();
		
		try {
			preparedStatement = connect.prepareStatement("SELECT  pharmacy_id, Name, Address_Line1, Address_Line2,"
					+ "City, State, country, ZipCode, latitude,longitude "
					+ "from logstash.pharmacy_info where pharmacy_id = "+pharmacyId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				pharmacy.setPharmacyId(resultSet.getString("pharmacy_id"));
				pharmacy.setPharmacyName(resultSet.getString("Name"));
				pharmacy.setAddressLine1(resultSet.getString("Address_Line1"));
				pharmacy.setAddressLine2(resultSet.getString("Address_Line2"));
				pharmacy.setCity(resultSet.getString("City"));
				pharmacy.setState(resultSet.getString("State"));
				pharmacy.setCountry(resultSet.getString("country"));
				pharmacy.setZipCode(resultSet.getString("ZipCode"));
				pharmacy.setLatitude(resultSet.getString("latitude"));
				pharmacy.setLongitude(resultSet.getString("longitude"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null) {
				resultSet.close();
			}
			if (preparedStatement != null) {
			    preparedStatement.close();
			}
			if (connect != null) {
				connect.close();
			}
		}
		return pharmacy;
	}

	public Prescription getPrescription(String PrescriptionId) throws SQLException {
		Connection connect = getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Prescription prescription = new Prescription();
		
		try {
			preparedStatement = connect.prepareStatement("SELECT  Rx_number, Fill_number, MaxFills, Estimated_Pickup_Time, Flag_Waiter_Later, "
					+ "Patient_id, NDC, route, prescriber_id, pharmacy_id, ICD, days_supply, Fill_date, last_fill_date, total_amount, fill_state, "
					+ "State_update_time from logstash.prescription where Rx_number ="+PrescriptionId+ " order by State_update_time desc limit 1");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				prescription.setRxNumber(resultSet.getString("Rx_number"));
				prescription.setFillNumber(resultSet.getString("Fill_number"));
				prescription.setMaxFills(resultSet.getString("MaxFills"));
				prescription.setEstimatedPickupTime(resultSet.getTimestamp("Estimated_Pickup_Time"));
				prescription.setFlagWaiterLater(resultSet.getString("Flag_Waiter_Later"));
				prescription.setPatient(getPatient(resultSet.getString("Patient_id")));
				prescription.setNdc(getNdc(resultSet.getString("NDC")));
				
				prescription.setPrescriber(getPrescriber(resultSet.getString("prescriber_id")));
				prescription.setPharmacy(getPharmacy(resultSet.getString("pharmacy_id")));
				prescription.setICD(resultSet.getString("ICD"));
				prescription.setDaysSupply(resultSet.getString("days_supply"));
				prescription.setFilldate(resultSet.getTimestamp("Fill_date"));
				prescription.setLastFillDate(resultSet.getTimestamp("last_fill_date"));
				prescription.setTotalAmount(resultSet.getString("total_amount"));
				prescription.setFillState(resultSet.getString("fill_state"));
				prescription.setStateUpdateTime(resultSet.getTimestamp("State_update_time"));
				prescription.setAdherenceScores(getAdherenceScore(prescription.getPatient().getPatientId(),prescription.getNdc().getPatientDrugId(),prescription.getLastFillDate(),prescription.getDaysSupply()));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (resultSet != null) {
				resultSet.close();
			}
			if (preparedStatement != null) {
			    preparedStatement.close();
			}
			if (connect != null) {
				connect.close();
			}
		}
		return prescription;
	}

	public void insertPatient(Patient p) throws SQLException {
		Connection conn = getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = conn.prepareStatement("insert into  logstash.patient_info values (?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?, ?)");
			preparedStatement.setString(1, p.getPatientId());
			preparedStatement.setString(2, p.getName());
			preparedStatement.setString(3, p.getAge());
			preparedStatement.setString(4, p.getGender());
			preparedStatement.setString(5, p.getAddressLine1());
			preparedStatement.setString(6, p.getAddressLine2());
			preparedStatement.setString(7, p.getCity());
			preparedStatement.setString(8, p.getState());
			preparedStatement.setString(9, p.getCountry());
			preparedStatement.setString(10,p.getZipCode());
			preparedStatement.setString(11,p.getLatitude());
			preparedStatement.setString(12,p.getLongitude());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (preparedStatement != null) {
			    preparedStatement.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}

	public void insertPresecriber(Prescriber p) throws SQLException {
		Connection conn = getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = conn.prepareStatement("insert into  logstash.prescriber_info values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			preparedStatement.setString(1, p.getPrescriberId());
			preparedStatement.setString(2, p.getName());
			preparedStatement.setString(3, p.getAge());
			preparedStatement.setString(4, p.getGender());
			preparedStatement.setString(5, p.getAddressLine1());
			preparedStatement.setString(6, p.getAddressLine2());
			preparedStatement.setString(7, p.getCity());
			preparedStatement.setString(8, p.getState());
			preparedStatement.setString(9, p.getCountry());
			preparedStatement.setString(10,p.getZipCode());
			preparedStatement.setString(11,p.getLatitude());
			preparedStatement.setString(12,p.getLongitude());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (preparedStatement != null) {
			    preparedStatement.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}

	public void insertPharmacy(Pharmacy p) throws SQLException {
		Connection conn = getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = conn.prepareStatement("insert into  logstash.pharmacy_info values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			preparedStatement.setString(1, p.getPharmacyId());
			preparedStatement.setString(2, p.getPharmacyName());
			preparedStatement.setString(3, p.getAddressLine1());
			preparedStatement.setString(4, p.getAddressLine2());
			preparedStatement.setString(5, p.getCity());
			preparedStatement.setString(6, p.getState());
			preparedStatement.setString(7, p.getCountry());
			preparedStatement.setString(8, p.getZipCode());
			preparedStatement.setString(9, p.getLatitude());
			preparedStatement.setString(10, p.getLongitude());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (preparedStatement != null) {
			    preparedStatement.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	}

	public void insertPrescription(Prescription p, boolean insert) throws SQLException {
		Connection conn = getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = conn.prepareStatement("insert into  logstash.prescription values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			preparedStatement.setString(1, p.getRxNumber());
			preparedStatement.setString(2, p.getFillNumber());
			preparedStatement.setString(3, p.getMaxFills());
			preparedStatement.setTimestamp(4, new java.sql.Timestamp(p.getEstimatedPickupTime().getTime()));
			preparedStatement.setString(5, p.getFlagWaiterLater());
			preparedStatement.setString(6, p.getPatient().getPatientId());
			preparedStatement.setString(7, p.getNdc().getPatientDrugId());
			preparedStatement.setString(8, "");
			preparedStatement.setString(9, p.getPrescriber().getPrescriberId());
			preparedStatement.setString(10,p.getPharmacy().getPharmacyId());
			preparedStatement.setString(11,p.getICD());
			preparedStatement.setString(12,p.getDaysSupply());
			preparedStatement.setTimestamp(13, p.getFilldate() != null ? new java.sql.Timestamp(p.getFilldate().getTime()) :  null);
			preparedStatement.setTimestamp(14, p.getLastFillDate() != null ? new java.sql.Timestamp(p.getLastFillDate().getTime()) : null);
			preparedStatement.setString(15,p.getTotalAmount());
			preparedStatement.setString(16,p.getFillState());
			preparedStatement.setTimestamp(17, new java.sql.Timestamp(p.getStateUpdateTime().getTime()));
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (preparedStatement != null) {
				preparedStatement.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		if(insert){
		insertNDC(p.getNdc());
		}
		if (p.getAdherenceScores() != null && !p.getAdherenceScores().isEmpty()) {
			insertAdherenceScore(p.getAdherenceScores());
		}
	}
	
	public void insertNDC(NDC ndc) throws SQLException {
		Connection conn = getConnection();
		PreparedStatement preparedStatement = null;

		try {
			for (DrugDetail drugDetail : ndc.getDrugDetail()) {
				preparedStatement = conn.prepareStatement("insert into  logstash.patient_drug_detail values (?, ?, ?, ?)");
				preparedStatement.setString(1, ndc.getPatientDrugId());
				preparedStatement.setString(2, ndc.getPrescriptionId());
				preparedStatement.setString(3, ndc.getPatientID());
				preparedStatement.setString(4,drugDetail.getDrugId());
				preparedStatement.executeUpdate();
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (conn != null) {
				conn.close();
			}
		}
	}
	
	public void insertAdherenceScore(List<AdherenceScore> adherenceScores) throws SQLException {
		Connection conn = getConnection();
		PreparedStatement preparedStatement = null;
		try {	AdherenceScore  temp = adherenceScores.get(0);
				preparedStatement = conn.prepareStatement("delete from logstash.patient_adherence_score where patient_id"
						+ " = "+temp.getPatientId()+" and year = "+temp.getYear()+" and month = "+temp.getMonth());
				preparedStatement.executeUpdate();
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		
		try {
			for (AdherenceScore adherenceScore : adherenceScores) {
				preparedStatement = conn.prepareStatement("insert into  logstash.patient_adherence_score values (?, ?, ?, ?, ?)");
				preparedStatement.setString(1, adherenceScore.getPatientId());
				preparedStatement.setString(2, adherenceScore.getDrugId());
				preparedStatement.setString(3, adherenceScore.getAdherenceScore());
				preparedStatement.setString(4, adherenceScore.getYear());
				preparedStatement.setString(5, adherenceScore.getMonth());
				preparedStatement.executeUpdate();
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			if (conn != null) {
				conn.close();
			}
		}
	}
	

	public void updatePrescriptionStatus(Prescription p) throws SQLException {
		insertPrescription(p, false);
	}
} 