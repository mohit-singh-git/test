package com.faker.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Prescription {
	
	
	
	private Patient patient;
	private Prescriber prescriber;
	private Pharmacy pharmacy;
	private List<AdherenceScore> adherenceScores = new ArrayList<AdherenceScore>();
	
	private String rxNumber; 
	private String fillNumber;
	private String maxFills;
	private Date estimatedPickupTime;
	private String flagWaiterLater; 
	private NDC ndc;
	private String ICD; 
	private String daysSupply;
	private Date filldate; 
	private Date lastFillDate; 
	private String totalAmount;
	private String fillState;
	private Date stateUpdateTime;
	
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	public Prescriber getPrescriber() {
		return prescriber;
	}
	public void setPrescriber(Prescriber prescriber) {
		this.prescriber = prescriber;
	}
	public Pharmacy getPharmacy() {
		return pharmacy;
	}
	public void setPharmacy(Pharmacy pharmacy) {
		this.pharmacy = pharmacy;
	}
	public String getRxNumber() {
		return rxNumber;
	}
	public void setRxNumber(String rxNumber) {
		this.rxNumber = rxNumber;
	}
	public String getFillNumber() {
		return fillNumber;
	}
	public void setFillNumber(String fillNumber) {
		this.fillNumber = fillNumber;
	}
	public String getMaxFills() {
		return maxFills;
	}
	public void setMaxFills(String maxFills) {
		this.maxFills = maxFills;
	}
	public Date getEstimatedPickupTime() {
		return estimatedPickupTime;
	}
	public void setEstimatedPickupTime(Date estimatedPickupTime) {
		this.estimatedPickupTime = estimatedPickupTime;
	}
	public String getFlagWaiterLater() {
		return flagWaiterLater;
	}
	public void setFlagWaiterLater(String flagWaiterLater) {
		this.flagWaiterLater = flagWaiterLater;
	}
	
	public String getICD() {
		return ICD;
	}
	public void setICD(String iCD) {
		ICD = iCD;
	}
	public String getDaysSupply() {
		return daysSupply;
	}
	public void setDaysSupply(String daysSupply) {
		this.daysSupply = daysSupply;
	}
	public Date getFilldate() {
		return filldate;
	}
	public void setFilldate(Date filldate) {
		this.filldate = filldate;
	}
	public Date getLastFillDate() {
		return lastFillDate;
	}
	public void setLastFillDate(Date lastFillDate) {
		this.lastFillDate = lastFillDate;
	}
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getFillState() {
		return fillState;
	}
	public void setFillState(String fillState) {
		this.fillState = fillState;
	}
	public Date getStateUpdateTime() {
		return stateUpdateTime;
	}
	public void setStateUpdateTime(Date stateUpdateTime) {
		this.stateUpdateTime = stateUpdateTime;
	}
	public NDC getNdc() {
		return ndc;
	}
	public void setNdc(NDC ndc) {
		this.ndc = ndc;
	}
	public List<AdherenceScore> getAdherenceScores() {
		return adherenceScores;
	}
	public void setAdherenceScores(List<AdherenceScore> adherenceScores) {
		this.adherenceScores = adherenceScores;
	}

}
