package com.faker.bean;

public class AdherenceScore {
	private String patientId;
	private String drugId;
	private String adherenceScore;
	private String year;
	private String month;
	
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getDrugId() {
		return drugId;
	}
	public void setDrugId(String drugId) {
		this.drugId = drugId;
	}
	public String getAdherenceScore() {
		return adherenceScore;
	}
	public void setAdherenceScore(String adherenceScore) {
		this.adherenceScore = adherenceScore;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
}
