package com.faker.bean;

import java.util.List;

public class NDC {
	private String patientDrugId;
	private String prescriptionId;
	private String patientID;
	private List<DrugDetail> drugDetail;
	public String getPatientDrugId() {
		return patientDrugId;
	}
	public void setPatientDrugId(String patientDrugId) {
		this.patientDrugId = patientDrugId;
	}
	public String getPrescriptionId() {
		return prescriptionId;
	}
	public void setPrescriptionId(String prescriptionId) {
		this.prescriptionId = prescriptionId;
	}
	public String getPatientID() {
		return patientID;
	}
	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}
	public List<DrugDetail> getDrugDetail() {
		return drugDetail;
	}
	public void setDrugDetail(List<DrugDetail> drugDetail) {
		this.drugDetail = drugDetail;
	}
		
}
