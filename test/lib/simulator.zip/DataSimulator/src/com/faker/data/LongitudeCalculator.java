package com.faker.data;

import java.util.Random;

public class LongitudeCalculator {

	public static String getLongitude(String state) {
		Random rand = new Random();
		float a =0;
		if (state.equals("Alabama")) {
			a = rand.nextInt(-84 - (-88)) + 1 + (-88);
		}
		if (state.equals("Alaska")) {
			a = rand.nextInt(-130 - (-173)) + 1 + (-173);
		}
		if (state.equals("Arizona")) {
			a = rand.nextInt(-109 - (-114)) + 1 + (-114);
		}
		if (state.equals("Arkansas")) {
			a = rand.nextInt(-89 - (-94)) + 1 + (-94);
		}
		if (state.equals("California")) {
			a = rand.nextInt(-114 - (-124)) + 1 + (-124);
		}
		if (state.equals("Colorado")) {
			a = rand.nextInt(-102 - (-109)) + 1 + (-102);
		}
		if (state.equals("Connecticut")) {
			a = rand.nextInt(-71 - (-73)) + 1 + (-73);
		}
		if (state.equals("Delaware")) {
			a = rand.nextInt(-75 - (-76)) + 1 + (-76);
		}
		if (state.equals("Florida")) {
			a = rand.nextInt(-79- (-87)) + 1 + (-87);
		}
		if (state.equals("Georgia")) {
			a = rand.nextInt(-81- (-85)) + 1 + (-85);
		}

		if (state.equals("Hawaii")) {
			a = rand.nextInt(-81- (-85)) + 1 + (-85);
		}

		if (state.equals("Idaho")) {
			a = rand.nextInt(-111- (-117)) + 1 + (-117);
		}

		if (state.equals("Illinois")) {
			a = rand.nextInt(-87- (-91)) + 1 + (-91);
		}

		if (state.equals("Indiana")) {
			a = rand.nextInt(-84- (-88)) + 1 + (-88);
		}

		if (state.equals("Iowa")) {
			a = rand.nextInt(-89- (-96)) + 1 + (-96);
		}

		if (state.equals("Kansas")) {
			a = rand.nextInt(-94- (-102)) + 1 + (-94);
		}

		if (state.equals("Kentucky")) {
			a = rand.nextInt(-81- (-89)) + 1 + (-89);
		}

		if (state.equals("Louisiana")) {
			a = rand.nextInt(-89- (-94)) + 1 + (-94);
		}
		if (state.equals("Maine")) {
				a = rand.nextInt(-66- (-71)) + 1 + (-71);	
			}
		if (state.equals("Maryland")) {
				a = rand.nextInt(-75- (-79)) + 1 + (-79);
			}
		if (state.equals("Massachusetts")) {
			a = rand.nextInt(-69- (-73)) + 1 + (-73);
		}

		if (state.equals("Michigan")) {
				a = rand.nextInt(-82- (-90)) + 1 + (-90);
		   }

		if (state.equals("Minnesota")) {
				a = rand.nextInt(-89- (-97)) + 1 + (-97);
			}
		if (state.equals("Mississippi")) {
				a = rand.nextInt(-88- (-91)) + 1 +(-91);
			}
		if (state.equals("Missouri")) {
				a = rand.nextInt(-89- (-96)) + 1 + (-96);
			}
		if (state.equals("Montana")) {
				a = rand.nextInt(-104- (-116)) + 1 + (-116);
			}
		if (state.equals("Nebraska")) {
				a = rand.nextInt(-92- (-104)) + 1 + (-104);
			}
		if (state.equals("Nevada")) {
				a = rand.nextInt(-114- (-120)) + 1 + (-120);
			}
		if (state.equals("New Hampshire")) {
				a = rand.nextInt(-70- (-72)) + 1 + (-72);
			}
		if (state.equals("New Jersey")) {
				a = rand.nextInt(-73- (-75)) + 1 + (-75);
			}
		if (state.equals("New Mexico")) {
				a = rand.nextInt(-103- (-109)) + 1 + (-109);
			}
		if (state.equals("New York")) {
				a = rand.nextInt(-71- (-79)) + 1 + (-79);
			}
		if (state.equals("North Carolina")) {
				a = rand.nextInt(-75- (-84)) + 1 + (-84);
			}
		if (state.equals("North Dakota")) {
				a = rand.nextInt(-97- (-104)) + 1 + (-104);
			}
		if (state.equals("Ohio")) {
				a = rand.nextInt(-80- (-84)) + 1 + (-84);
			}
		if (state.equals("Oklahoma")) {
				a = rand.nextInt(-94- (-103)) + 1 + (-103);
			}
		if (state.equals("Oregon")) {
				a = rand.nextInt(-116- (-124)) + 1 + (-124);
			}
		if (state.equals("Pennsylvania")) {
				a = rand.nextInt(-74- (-80)) + 1 + (-80);
			}
		if (state.equals("Rhode Island")) {
				a = rand.nextInt(-71- (-72)) + 1 + (-72);
			}
		if (state.equals("South Carolina")) {
				a = rand.nextInt(-78- (-83)) + 1 + (-83);
			}
		if (state.equals("South Dakota")) {
				a = rand.nextInt(-98- (-104)) + 1 + (-104);
			}
		if (state.equals("Tennessee")) {
				a = rand.nextInt(-81- (-90)) + 1 + (-90);
			}
		if (state.equals("Texas")) {
				a = rand.nextInt(-93- (-106)) + 1 + (-106);
			}
		if (state.equals("Utah")) {
				a = rand.nextInt(-109- (-114)) + 1 + (-114);
			}
		if (state.equals("Vermont")) {
				a = rand.nextInt(-71- (-73)) + 1 + (-73);
			}
		if (state.equals("Virginia")) {
				a = rand.nextInt(-75- (-83)) + 1 + (-83);
			}
		if (state.equals("Washington")) {
				a = rand.nextInt(-116- (-124)) + 1 + (-124);
			}
		if (state.equals("West Virginia")) {
				a = rand.nextInt(-77- (-82)) + 1 + (-82);
			}
		if (state.equals("Wisconsin")) {
				a = rand.nextInt(-86- (-92)) + 1 + (-92);
			}
		if (state.equals("Wyoming")) {
				a = rand.nextInt(-104- (-111)) + 1 + (-111);
			}
		Random generator = new Random();
		int number = generator.nextInt(9);
		double result = number / 1000000.0;
		return String.valueOf(Double.valueOf(a).doubleValue()+result).toString();
	}
	
	public static String getLatitude(String state) {
		Random rand = new Random();
		float a =0;
		if (state.equals("Alabama")) {
			a = rand.nextInt(35 - 30) + 1 +30;
		}
		if (state.equals("Alaska")) {
			a = rand.nextInt(71 - 54) + 1 +54;
		}
		if (state.equals("Arizona")) {
			a = rand.nextInt(37 - 31) + 1 +31;
		}
		if (state.equals("Arkansas")) {
			a = rand.nextInt(36 - 33) + 1 +33;
		}
		if (state.equals("California")) {
			a = rand.nextInt(42 - 32) + 1 +32;
		}
		if (state.equals("Colorado")) {
			a = rand.nextInt(41 - 37) + 1 +37;
		}
		if (state.equals("Connecticut")) {
			a = rand.nextInt(42 - 40) + 1 +40;
		}
		if (state.equals("Delaware")) {
			a = rand.nextInt(40 - 38) + 1 +38;
		}
		if (state.equals("Florida")) {
			a = rand.nextInt(31 - 24) + 1 +24;
		}
		if (state.equals("Georgia")) {
			a = rand.nextInt(35 - 30) + 1 +30;
		}

		if (state.equals("Hawaii")) {
			a = rand.nextInt(23 - 16) + 1 +16;
		}

		if (state.equals("Idaho")) {
			a = rand.nextInt(49 - 42) + 1 +42;
		}

		if (state.equals("Illinois")) {
			a = rand.nextInt(42 - 30) + 1 +36;
		}

		if (state.equals("Indiana")) {
			a = rand.nextInt(41 - 30) + 1 +37;
		}

		if (state.equals("Iowa")) {
			a = rand.nextInt(43 - 40) + 1 +40;
		}

		if (state.equals("Kansas")) {
			a = rand.nextInt(40 - 37) + 1 +37;
		}

		if (state.equals("Kentucky")) {
			a = rand.nextInt(39 - 36) + 1 +36;
		}

		if (state.equals("Louisiana")) {
			a = rand.nextInt(33 - 29) + 1 +29;
		}
		if (state.equals("Maine")) {
			a = rand.nextInt(47 - 43) + 1 +43;
			}
		if (state.equals("Maryland")) {
			a = rand.nextInt(39 - 37) + 1 +37;
			}
		if (state.equals("Massachusetts")) {
			a = rand.nextInt(42 - 41) + 1 +41;
		}

		if (state.equals("Michigan")) {
			a = rand.nextInt(47 - 41) + 1 +41;
		   }

		if (state.equals("Minnesota")) {
			a = rand.nextInt(49 - 43) + 1 +43;
			}
		if (state.equals("Mississippi")) {
			a = rand.nextInt((35 - 30) + 1) +30;
			}
		if (state.equals("Missouri")) {
			a = rand.nextInt(40 - 36) + 1 +36;
			}
		if (state.equals("Montana")) {
			a = rand.nextInt(49 - 44) + 1 +44;
			}
		if (state.equals("Nebraska")) {
			a = rand.nextInt(43 - 40) + 1 +40;
			}
		if (state.equals("Nevada")) {
			a = rand.nextInt(42 - 35) + 1 +35;
			}
		if (state.equals("New Hampshire")) {
			a = rand.nextInt(45 - 42) + 1 +42;
			}
		if (state.equals("New Jersey")) {
			a = rand.nextInt(41 - 38) + 1 +38;
			}
		if (state.equals("New Mexico")) {
			a = rand.nextInt(37 - 31) + 1 +31;
			}
		if (state.equals("New York")) {
			a = rand.nextInt(45 - 40) + 1 +40;
			}
		if (state.equals("North Carolina")) {
			a = rand.nextInt(36 - 34) + 1 +34;
			}
		if (state.equals("North Dakota")) {
			a = rand.nextInt(49 - 45) + 1 +45;
			}
		if (state.equals("Ohio")) {
			a = rand.nextInt(41 - 38) + 1 +38;
			}
		if (state.equals("Oklahoma")) {
			a = rand.nextInt(37 - 33) + 1 +33;
			}
		if (state.equals("Oregon")) {
			a = rand.nextInt(46 - 42) + 1 +42;
			}
		if (state.equals("Pennsylvania")) {
			a = rand.nextInt(42 - 39) + 1 +39;
			}
		if (state.equals("Rhode Island")) {
			a = rand.nextInt(42 - 41) + 1 +41;
			}
		if (state.equals("South Carolina")) {
			a = rand.nextInt(35 - 32) + 1 +32;
			}
		if (state.equals("South Dakota")) {
			a = rand.nextInt(45 - 42) + 1 +42;
			}
		if (state.equals("Tennessee")) {
			a = rand.nextInt(36 - 35) + 1 +35;
			}
		if (state.equals("Texas")) {
			a = rand.nextInt(36 - 25) + 1 +25;
			}
		if (state.equals("Utah")) {
			a = rand.nextInt(42 - 37) + 1 +37;
			}
		if (state.equals("Vermont")) {
			a = rand.nextInt(45 - 42) + 1 +42;
			}
		if (state.equals("Virginia")) {
			a = rand.nextInt(39 - 36) + 1 +36;
			}
		if (state.equals("Washington")) {
			a = rand.nextInt(49 - 45) + 1 +45;
			}
		if (state.equals("West Virginia")) {
			a = rand.nextInt(40 - 37) + 1 +37;
			}
		if (state.equals("Wisconsin")) {
			a = rand.nextInt(47 - 42) + 1 +42;
			}
		if (state.equals("Wyoming")) {
			a = rand.nextInt(45 - 41) + 1 +41;
			}
		Random generator = new Random();
		int number = generator.nextInt(9);
		double result = number / 1000000.0;
		return String.valueOf(Double.valueOf(a).doubleValue()+result).toString();
	}
}
