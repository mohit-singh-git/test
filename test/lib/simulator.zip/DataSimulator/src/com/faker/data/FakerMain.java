package com.faker.data;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang.time.DateUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.faker.bean.AdherenceScore;
import com.faker.bean.DrugDetail;
import com.faker.bean.NDC;
import com.faker.bean.Patient;
import com.faker.bean.Pharmacy;
import com.faker.bean.Prescriber;
import com.faker.bean.Prescription;
import com.faker.dao.MySQLAccess;
import com.mysql.jdbc.exceptions.jdbc4.CommunicationsException;

public class FakerMain {
	
	public static final int maxRangePatient = 200000;
	public static final int maxrangePharmacy = 4000;
	public static final int maxRangePrescriber = 4000;
	public static final int maxRangePrescription = 250000;
	public static final int monthsBefore = 1;
	public static final long maxLoop = 999999999;
	public static final String STATE_FILL_COMPLETE = "Fill Complete";
	public static final String STATE_PICKUP = "PickUp";
	public static final String STATE_TRANSFER = "Transfer";
	public static final String STATE_REJECTED = "Rejected";
	public static final String STATE_REFILL = "Refill";
	public static final String STATE_CREATED = "Created";
	public static void main(String[] args) throws NumberFormatException, SQLException, java.text.ParseException {
		
		MySQLAccess access = new MySQLAccess();
		int maxPatientid  = Integer.valueOf(access.getMaxPatientId());
		int maxPriscriberId = Integer.valueOf(access.getMaxPresecriberId());
		int maxPharmacyId = Integer.valueOf(access.getMaxPharmacyId());
		int maxPriscriptionId = Integer.valueOf(access.getMaxPriscriptionId());
		long maxCount = 0;
		while (maxCount< maxLoop) {
		Patient patient = null;
		Prescriber prescriber = null;
		Pharmacy pharmacy = null;
		Prescription prescription =null;
		try {
		if (maxPatientid < maxRangePatient) {
			patient = getNewPatient();
			patient.setPatientId(String.valueOf((++maxPatientid)));
			access.insertPatient(patient);
		}
		if (maxPriscriberId < maxRangePrescriber) {
			prescriber = getNewPrescriber();
			prescriber.setPrescriberId(String.valueOf((++maxPriscriberId)));
			access.insertPresecriber(prescriber);
		}
		if (maxPharmacyId <= maxrangePharmacy) {
			pharmacy = getNewPharmacy();
			pharmacy.setPharmacyId(String.valueOf((++maxPharmacyId)));
			access.insertPharmacy(pharmacy);
		}
		Random rand = new Random();
		if ((rand.nextInt((10 - 1) + 1) + 1) > 5 && maxPriscriptionId > 1) {
			int randomPresciption = rand.nextInt((maxPriscriptionId - 1) + 1) + 1;
			prescription = access.getPrescription(String.valueOf(randomPresciption));

			if (prescription.getFillState().equals(STATE_CREATED) || prescription.getFillState().equals(STATE_REFILL)) {
				if (rand.nextInt((10 - 1) + 1) + 1 > 3) {
					prescription.setFillState(STATE_PICKUP);
					int up_time = rand.nextInt((7 - 1) + 1) + 1;
					Date newStateUpdateDate = DateUtils.addHours(prescription.getStateUpdateTime(), up_time);
					prescription.setStateUpdateTime(newStateUpdateDate);
					access.updatePrescriptionStatus(prescription);
					System.out.println("Pickup state updated for      : " + prescription.getRxNumber());
				} else {
					if (rand.nextInt((10 - 1) + 1) + 1 > 4) {
						prescription.setFillState(STATE_REJECTED);
						int up_time = rand.nextInt((7 - 1) + 1) + 1;
						Date newStateUpdateDate = DateUtils.addHours(prescription.getStateUpdateTime(), up_time);
						prescription.setStateUpdateTime(newStateUpdateDate);
						access.updatePrescriptionStatus(prescription);
						System.out.println("Rejected state updated for    : " + prescription.getRxNumber());


					} else {
						prescription.setFillState(STATE_TRANSFER);
						int up_time = rand.nextInt((7 - 1) + 1) + 1;
						Date newStateUpdateDate = DateUtils.addHours(prescription.getStateUpdateTime(), up_time);
						prescription.setStateUpdateTime(newStateUpdateDate);
						access.updatePrescriptionStatus(prescription);
						System.out.println("Transfer state updated for    : " + prescription.getRxNumber());
					}
				}
			} else if (prescription.getFillState().equals(STATE_PICKUP)) {
				prescription.setFillState(STATE_FILL_COMPLETE);
				int up_time = rand.nextInt((7 - 1) + 1) + 1;
				Date newStateUpdateDate = DateUtils.addHours(prescription.getStateUpdateTime(), up_time);
				prescription.setStateUpdateTime(newStateUpdateDate);
				prescription.setFilldate(newStateUpdateDate);
				prescription.setLastFillDate(newStateUpdateDate);
				access.updatePrescriptionStatus(prescription);
				System.out.println("FillComplete state updated    : " + prescription.getRxNumber());

			} else if (prescription.getFillState().equals(STATE_FILL_COMPLETE)){
				if (Integer.valueOf(prescription.getFillNumber()).intValue() < Integer.valueOf(prescription.getMaxFills())) {
					prescription = getRefillPrescription(prescription);
					if (prescription == null) {
						continue;
					}
					prescription.setFilldate(null);
					access.insertPrescription(prescription,false);
				}
			}
		} else if (maxPriscriptionId < maxRangePrescription){
				prescription = getNewPrescription(maxPriscriptionId);
				prescription.setRxNumber(String.valueOf((++maxPriscriptionId)));
				prescription.setPatient(patient != null ? patient : access.getPatient(String.valueOf(rand.nextInt((maxRangePatient - 1) + 1) + 1)));
				prescription.setPharmacy(pharmacy != null ? pharmacy : access.getPharmacy(String.valueOf(rand.nextInt((maxrangePharmacy - 1) + 1) + 1)));
				prescription.setPrescriber(prescriber != null ? prescriber : access.getPrescriber(String.valueOf(rand.nextInt((maxRangePrescriber - 1) + 1) + 1)));
				prescription.setNdc(getNewNDC(prescription.getPatient().getPatientId(), prescription.getRxNumber(), access));
				access.insertPrescription(prescription,true);
				System.out.println("Created New Prescription      : " + prescription.getRxNumber());
			}

		} catch (CommunicationsException e) {
			access.getConnection();
		}
		maxCount++;
	}
	}

	public static Patient getNewPatient() {
		Patient patient = new Patient();
		try {  
		URL urlUser = new URL("http://localhost:8080/api/user");
		HttpURLConnection conn = (HttpURLConnection) urlUser.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Accept", "application/json");

		if (conn.getResponseCode() != 200) {
			System.out.println("Faker Api connection issue");
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode());
		}

		BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
		JSONObject json = (JSONObject)new JSONParser().parse(br.readLine());
	
		conn.disconnect();

		patient.setName(json.get("firstName") +" "+json.get("lastName"));
		patient.setAge(json.get("age").toString());
		Random rand = new Random();
		int randomNum = rand.nextInt((10 - 1) + 1) + 1;
		patient.setGender(randomNum >= 5 ? "M":"F");
		patient.setAddressLine1(json.get("address").toString());
		patient.setAddressLine2("");
		patient.setCity(json.get("city").toString());
		patient.setState(json.get("state").toString());
		patient.setCountry(json.get("country").toString());
		patient.setZipCode(json.get("zipcode").toString());
		patient.setLatitude(LongitudeCalculator.getLongitude(json.get("state").toString()));
		patient.setLongitude(LongitudeCalculator.getLatitude(json.get("state").toString()));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return patient;
	}

	public static Prescriber getNewPrescriber() {
		Prescriber prescriber = new Prescriber();
		try {
			URL urlPrescriber = new URL("http://localhost:8080/api/prescriber");
			HttpURLConnection conn = (HttpURLConnection) urlPrescriber.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != 200) {
				System.out.println("Faker Api connection issue");
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			JSONObject json = (JSONObject)new JSONParser().parse(br.readLine());
			prescriber.setName(json.get("firstName") +" "+json.get("lastName"));
			prescriber.setAge(json.get("age").toString());
			Random rand = new Random();
			int randomNum = rand.nextInt((10 - 1) + 1) + 1;
			prescriber.setGender(randomNum >= 5 ? "M":"F");
			prescriber.setAddressLine1(json.get("address").toString());
			prescriber.setAddressLine2("");
			prescriber.setCity(json.get("city").toString());
			prescriber.setState(json.get("state").toString());
			prescriber.setCountry(json.get("country").toString());
			prescriber.setZipCode(json.get("zipcode").toString());
			prescriber.setLatitude(LongitudeCalculator.getLongitude(json.get("state").toString()));
			prescriber.setLongitude(LongitudeCalculator.getLatitude(json.get("state").toString()));

			conn.disconnect();

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return prescriber;
	}

	public static Pharmacy getNewPharmacy() {
		Pharmacy pharmacy = new Pharmacy();
		try {
			URL urlPharmacy = new URL("http://localhost:8080/api/pharmacy");
			HttpURLConnection conn = (HttpURLConnection) urlPharmacy.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != 200) {
				System.out.println("Faker Api connection issue");
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			JSONObject json = (JSONObject)new JSONParser().parse(br.readLine());
			pharmacy.setPharmacyName(json.get("name").toString());
			pharmacy.setAddressLine1(json.get("address").toString());
			pharmacy.setCity(json.get("city").toString());
			pharmacy.setState(json.get("state").toString());
			pharmacy.setCountry(json.get("country").toString());
			pharmacy.setZipCode(json.get("zipcode").toString());
			pharmacy.setLatitude(LongitudeCalculator.getLongitude(json.get("state").toString()));
			pharmacy.setLongitude(LongitudeCalculator.getLatitude(json.get("state").toString()));
			conn.disconnect();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return pharmacy;
	}

	public static Prescription getNewPrescription(int maxPriscriptionId) throws java.text.ParseException {
		Prescription prescription = new Prescription();
		Date startDate = DateUtils.addMonths(new Date(), -monthsBefore);
		Random rand = new Random();
		int days = maxPriscriptionId /(200 + (rand.nextInt((20 - 1) + 1) + 1));
		startDate = DateUtils.addDays(startDate, days);
		if (startDate.after(new Date())) {
			startDate = new Date();
		}
		prescription.setStateUpdateTime(startDate);

		int max_fill = rand.nextInt((20 - 1) + 1) + 1;
		prescription.setFillNumber(Integer.valueOf(rand.nextInt((max_fill - 1) + 1) + 1).toString());
		prescription.setMaxFills(Integer.valueOf(max_fill).toString());

		int pick_up_time = rand.nextInt((-3 - (-30)) + 1) -30;
		Date pickUpDate = DateUtils.addHours(startDate, pick_up_time);
		prescription.setEstimatedPickupTime(pickUpDate);

		prescription.setFlagWaiterLater(rand.nextInt((10 - 1) + 1) + 1 > 5  ? "Waiter" : "Later");

		prescription.setICD("ICD" + max_fill);

		prescription.setDaysSupply(Integer.valueOf(rand.nextInt((15 - 1) + 1) + 1).toString());

		if (Integer.valueOf(prescription.getFillNumber()).intValue() > 1) {
			int last_fill = rand.nextInt((-3 - (-30)) + 1) + (-30);

			Date lastFillDate = DateUtils.addDays(startDate, last_fill);
			prescription.setLastFillDate(lastFillDate);
		}

		float total_amount = rand.nextInt((500 - 2) + 1) + 2;
		prescription.setTotalAmount(String.valueOf(total_amount).toString());

		prescription.setFillState(STATE_CREATED);

		return prescription;
	}
	
	public static Prescription getRefillPrescription(Prescription prescription) throws java.text.ParseException {
	
		Random rand = new Random();
		Date lastFillDate = prescription.getLastFillDate();
		int daysSupply = Integer.valueOf(prescription.getDaysSupply()).intValue();
		Date shoulBeRefilledOn = DateUtils.addDays(lastFillDate, daysSupply);
		
		int delayOrEarly = rand.nextInt(10 - (-daysSupply)) + 1 + (-daysSupply);
		int temp = daysSupply + delayOrEarly;
		int adhScore = (daysSupply * 100 / temp) ;
		if (adhScore > 100) {
			adhScore = 100;
		}
		Date actualRefilledOn = DateUtils.addDays(shoulBeRefilledOn, delayOrEarly);
		if (actualRefilledOn.after(new Date())) {
			return null;
		}
		List<AdherenceScore> adherenceScores = prescription.getAdherenceScores();
		String month = "";
		String year = "";
		Map<String, AdherenceScore> map = new HashMap<String, AdherenceScore>();
		for (AdherenceScore adherenceScore : adherenceScores) {
			month  = adherenceScore.getMonth();
			year   = adherenceScore.getYear();
			map.put(adherenceScore.getDrugId(), adherenceScore);
		}
		for (DrugDetail drugDetail : prescription.getNdc().getDrugDetail()) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(shoulBeRefilledOn);
			if (month.equals(String.valueOf(cal.get(Calendar.MONTH))) && year.equals(String.valueOf(cal.get(Calendar.YEAR)))) {
				AdherenceScore adherenceScore = map.get(drugDetail.getDrugId());
				adherenceScore.setAdherenceScore(String.valueOf((Integer.valueOf(adherenceScore.getAdherenceScore()).intValue() + adhScore) / 2).toString());
			} else {
			AdherenceScore adherenceScore = new AdherenceScore();
			adherenceScore.setPatientId(prescription.getPatient().getPatientId());
			adherenceScore.setDrugId(drugDetail.getDrugId());
			adherenceScore.setAdherenceScore(String.valueOf(adhScore).toString());
			adherenceScore.setMonth(String.valueOf(cal.get(Calendar.MONTH)));
			adherenceScore.setYear(String.valueOf(cal.get(Calendar.YEAR)));
			adherenceScores.add(adherenceScore);
			}
		}
		
		prescription.setStateUpdateTime(actualRefilledOn);
		prescription.setFillState(STATE_REFILL);
		
		prescription.setFillNumber(String.valueOf((Integer.valueOf(prescription.getFillNumber()) +1)).toString());
		
		int pick_up_time = rand.nextInt((23 - 1) + 1) + 1;
		Date pickUpDate = DateUtils.addHours(actualRefilledOn, pick_up_time);
		prescription.setEstimatedPickupTime(pickUpDate);
		
		prescription.setFlagWaiterLater(rand.nextInt((10 - 1) + 1) + 1 > 5  ? "Waiter" : "Later");
		
		int newSuplyDay = rand.nextInt((15 - 1) + 1) + 1;
		prescription.setDaysSupply(Integer.valueOf(newSuplyDay).toString());
		
		prescription.setFilldate(actualRefilledOn);
		
		float total_amount = (Float.valueOf(prescription.getTotalAmount().substring(1)) / daysSupply) * newSuplyDay;
		prescription.setTotalAmount(String.valueOf(total_amount));
		System.out.println("Refilled existing prescription: "+ prescription.getRxNumber());
		return prescription;
	}
	
	public static NDC getNewNDC(String patientId, String prescriptionId, MySQLAccess access) throws SQLException {
		Random rand = new Random();
		NDC ndc = new NDC();
		ndc.setPatientID(patientId);
		ndc.setPrescriptionId(prescriptionId);
		ndc.setPatientDrugId(patientId+prescriptionId+Integer.valueOf(rand.nextInt((10 - 1) + 1) + 1).toString());
		ndc.setDrugDetail(access.getDrug(Integer.valueOf(rand.nextInt((10 - 1) + 1) + 1)));
		return ndc;
	}
	
}
