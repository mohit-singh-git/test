package com.walgreens.dae.data.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;

public class FourColumnRowMapper implements RowMapper<Object> {
	
	private String firstColumnName = "";
	private String secondColumnName = "";
	private String thirdColumnName = "";
	private String fourtColumnName = "";
	
	
	Map<String,Map<String,Map<String,String>>> result= null;

	public Map<String, Map<String, Map<String, String>>> getResult() {
		return result;
	}

	public void setResult(Map<String, Map<String, Map<String, String>>> result) {
		this.result = result;
	}

	@Override
	public Object mapRow(ResultSet rs, int row) throws SQLException {
		if (rs != null) {
			String paramType = rs.getString(getFirstColumnName());
			String subParamType = rs.getString(getSecondColumnName());
			String key = rs.getString(getThirdColumnName());
			String value = rs.getString(getFourtColumnName());
			if (getResult().containsKey(paramType)) {
				if (getResult().get(paramType).containsKey(subParamType)) {
					getResult().get(paramType).get(subParamType).put(key, value);
				} else {
					Map<String,String> keyValueMap = new HashMap<String,String>();
					keyValueMap.put(key, value);
					getResult().get(paramType).put(subParamType, keyValueMap);
				}
			} else {
				Map<String, Map<String, String>> subParamMap = new HashMap<String, Map<String, String>>();
				Map<String,String> keyValueMap = new HashMap<String,String>();
				keyValueMap.put(key, value);
				subParamMap.put(subParamType, keyValueMap);
				getResult().put(paramType, subParamMap);
			}
			}
		return null;
	}

	public String getFirstColumnName() {
		return firstColumnName;
	}

	public void setFirstColumnName(String firstColumnName) {
		this.firstColumnName = firstColumnName;
	}

	public String getSecondColumnName() {
		return secondColumnName;
	}

	public void setSecondColumnName(String secondColumnName) {
		this.secondColumnName = secondColumnName;
	}

	public String getThirdColumnName() {
		return thirdColumnName;
	}

	public void setThirdColumnName(String thirdColumnName) {
		this.thirdColumnName = thirdColumnName;
	}

	public String getFourtColumnName() {
		return fourtColumnName;
	}

	public void setFourtColumnName(String fourtColumnName) {
		this.fourtColumnName = fourtColumnName;
	}

	

}
