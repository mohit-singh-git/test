package com.walgreens.dae.data.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class OneColumnRowMapper implements RowMapper<Object> {
	
	private String firstColumnName;
	private String result ="";


	@Override
	public String mapRow(ResultSet rs, int row) throws SQLException {
		if (rs != null) {
			setResult(rs.getString(getFirstColumnName()));
			}
		return getResult();
	}

	
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}
	
	public String getFirstColumnName() {
		return firstColumnName;
	}

	public void setFirstColumnName(String firstColumnName) {
		this.firstColumnName = firstColumnName;
	}
}
