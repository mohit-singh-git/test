package com.walgreens.dae.process.subprocess;

import org.springframework.stereotype.Component;

import com.walgreens.dae.bean.JobParameterBean;

@Component
public class JobExitProcess {
	public void execute(JobParameterBean jobParameterBean) {
		System.exit(jobParameterBean.getExitCode());
	}
}
