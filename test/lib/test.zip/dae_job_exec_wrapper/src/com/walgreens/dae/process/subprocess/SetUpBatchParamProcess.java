package com.walgreens.dae.process.subprocess;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walgreens.dae.bean.JobParameterBean;
import com.walgreens.dae.dao.DAEMetadataDAO;

@Component
public class SetUpBatchParamProcess {

	@Autowired
	DAEMetadataDAO dAEMetadataDAO;

	public void execute(String projectName, String jobName, JobParameterBean jobParameterBean) {
		Map<String,Map<String,String>> executionFrameworkGlobalParam = new HashMap<String,Map<String,String>>();
		Map<String, String> hadoopEngineParam = new HashMap<String, String>();

		String batchId = dAEMetadataDAO.getMaxEdwBatchId(projectName, jobName);

		Map<String,Map<String,Map<String,String>>> jobparam = dAEMetadataDAO.getJobParam(projectName, jobName);

		if (jobparam.containsKey("engine")) {
			Map<String,String> executionFramework = jobparam.get("engine").get("executionFramework");
			for (Map.Entry<String, String> entry : executionFramework.entrySet()) {
				executionFrameworkGlobalParam.putAll(dAEMetadataDAO.getEngineGlobalParam(entry.getKey()));
			}

			Map<String,String> processingEngine = jobparam.get("engine").get("processingEngine");
			for (Map.Entry<String, String> entry : processingEngine.entrySet()) { 
				hadoopEngineParam.putAll(dAEMetadataDAO.getHadoopEngineGlobalParam(entry.getValue(), entry.getKey()));
			}
		}
		

		jobParameterBean.setBatchId(batchId);
		jobParameterBean.setExecutionFrameworkGlobalParam(executionFrameworkGlobalParam);
		jobParameterBean.setHadoopEngineParam(hadoopEngineParam);
		jobParameterBean.setJobparam(jobparam);
	}
}
