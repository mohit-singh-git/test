package com.walgreens.dae.process.subprocess;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.walgreens.dae.bean.JobParameterBean;

@Component
public class AuditProcess {
	Logger logger = Logger.getLogger(AuditProcess.class);
	public void execute(JobParameterBean jobParameterBean) {
		if (jobParameterBean.getJobparam()!= null && jobParameterBean.getJobparam().containsKey("datapath")) {
			if (jobParameterBean.getJobparam().get("datapath").containsKey("audit")) {
				if (jobParameterBean.getJobparam().get("datapath").get("audit").containsKey("audit_trail_file")) {
					if (jobParameterBean.getJobparam().
							get("datapath").get("audit").get("audit_trail_file").equals("yes")) {
						Map<String, String> dataFileInputPath = jobParameterBean.getJobparam().
								get("datapath").get("dataFileInputPath");
						for (Map.Entry<String, String> path : dataFileInputPath.entrySet()) {
							String filepath = path.getValue() + jobParameterBean.getBatchId();
							String command = "hadoop fs -cat "+filepath+"/* | wc -1";
							Process p;
							try {
								p = Runtime.getRuntime().exec(command);
								BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
								BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
								logger.info("Record count at path "+ filepath + " : "+stdInput.toString());
								logger.error(stdError.toString());
							} catch (IOException e) {
								e.printStackTrace();
							} 
						}
					}
				}
			}
		}
	}
}
