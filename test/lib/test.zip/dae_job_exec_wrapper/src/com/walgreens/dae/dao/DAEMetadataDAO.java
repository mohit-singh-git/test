package com.walgreens.dae.dao;


import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.walgreens.dae.data.rowmapper.FourColumnRowMapper;
import com.walgreens.dae.data.rowmapper.TwoColumnRowMapper;
import com.walgreens.dae.process.wrapper.DAEJobExecWrapperMain;
import com.walgreens.dae.data.rowmapper.OneColumnRowMapper;
import com.walgreens.dae.data.rowmapper.ThreeColumnRowMapper;

@Component
@Configuration
@PropertySource("classpath:queries.properties")
public class DAEMetadataDAO extends JdbcDaoSupport implements Serializable {

	private static final long serialVersionUID = 1779892133952643142L;

	@Autowired
	private DataSource dataSource;

	@Value(value = "${processControl.EnvValueQuery}")
	private String envValueQuery;
	@Value(value = "${processControl.MaxEdwBatchIdQuery}")
	private String maxEdwBatchIdQuery;
	@Value(value = "${processControl.JobParams}")
	private String jobParams;
	@Value(value = "${processControl.ExecutionEngineParam}")
	private String executionEngineParam;
	@Value(value = "${processControl.HadoopEngineParam}")
	private String hadoopEngineParam;
	@Value(value = "${processControl.JobRunSeqNum}")
	private String jobRunSeqNum;
	@Value(value = "${processControl.UpdateRunSeqNum}")
	private String updateRunSeqNum;
	@Value(value = "${processControl.UpdateJobStatus}")
	private String updateJobStatus;

	Logger logger = Logger.getLogger(DAEJobExecWrapperMain.class);

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

	public void updateJobStatus(String projectName, String jobName, String batchId, String status) {
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(getJdbcTemplate());
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("project_name", projectName);
			params.put("job_name", jobName);
			params.put("edwbatchId",batchId);
			params.put("status",status);
			namedParameterJdbcTemplate.update(updateJobStatus, params);
		} catch (Exception e) {
			logger.error(e.toString());
		}
	}

	public void updateJobRunSeqAndStatus(String projectName, String jobName, String batchId, int lastRunSeq) {
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(getJdbcTemplate());
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("project_name", projectName);
			params.put("job_name", jobName);
			params.put("edwbatchId",batchId);
			params.put("lastRunSeq",lastRunSeq);
			params.put("status","Running");
			namedParameterJdbcTemplate.update(updateRunSeqNum, params);
		} catch (Exception e) {
			logger.error(e.toString());
		}
	}

	public Map<String, String> getJobRunSeqAndStatus(String projectName, String jobName, String edwbatchId) {
		Map<String, String> resultMap = new HashMap<String, String>();
		try {
			TwoColumnRowMapper rowMapper = new TwoColumnRowMapper();
			rowMapper.setResultMap(resultMap);
			rowMapper.setFirstColumnName("seq_number");
			rowMapper.setSecondColumnName("status");
			rowMapper.setColumnNameAsKey(true);
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(getJdbcTemplate());
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("project_name", projectName);
			params.put("job_name", jobName);
			params.put("edwbatchId", edwbatchId);
			namedParameterJdbcTemplate.query(jobRunSeqNum, params, rowMapper);
		} catch (Exception e) {
			logger.error(e.toString());
		}
		return resultMap;
	}

	public Map<String, String> getEnvVar(String projectName, String jobName) {
		Map<String, String> resultMap = new HashMap<String, String>();
		try {
			TwoColumnRowMapper rowMapper = new TwoColumnRowMapper();
			rowMapper.setResultMap(resultMap);
			rowMapper.setFirstColumnName("env_key");
			rowMapper.setSecondColumnName("env_value");
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(getJdbcTemplate());
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("project_name", projectName);
			params.put("job_name", jobName);
			namedParameterJdbcTemplate.query(envValueQuery, params, rowMapper);
		} catch (Exception e) {
			logger.error(e.toString());
		}
		return resultMap;
	}

	public String getMaxEdwBatchId(String projectName, String jobName) {
		OneColumnRowMapper rowMapper = new OneColumnRowMapper();
		try {
			rowMapper.setFirstColumnName("edwbatchid");
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(getJdbcTemplate());
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("project_name", projectName);
			params.put("job_name", jobName);
			namedParameterJdbcTemplate.query(maxEdwBatchIdQuery, params, rowMapper);
		} catch (Exception e) {
			logger.error(e.toString());
		}
		return rowMapper.getResult();
	}

	public Map<String,Map<String,Map<String,String>>> getJobParam(String projectName, String jobName) {
		Map<String,Map<String,Map<String,String>>> result =  new HashMap<String,Map<String,Map<String,String>>>();
		try {
			FourColumnRowMapper rowMapper = new FourColumnRowMapper();
			rowMapper.setResult(result);
			rowMapper.setFirstColumnName("parameter_type");
			rowMapper.setSecondColumnName("sub_parameter_type");
			rowMapper.setThirdColumnName("key");
			rowMapper.setFourtColumnName("value");
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(getJdbcTemplate());
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("project_name", projectName);
			params.put("job_name", jobName);
			namedParameterJdbcTemplate.query(jobParams, params, rowMapper);
		} catch (Exception e) {
			logger.error(e.toString());
		}
		return result;
	}

	public Map<String, Map<String,String>> getEngineGlobalParam(String executionEngine) {
		Map<String,Map<String,String>> result =  new HashMap<String,Map<String,String>>();
		try {
			ThreeColumnRowMapper rowMapper = new ThreeColumnRowMapper();
			rowMapper.setResult(result);
			rowMapper.setFirstColumnName("execution_engine");
			rowMapper.setSecondColumnName("global_parameters");
			rowMapper.setThirdColumnName("value");
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(getJdbcTemplate());
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("executionEngine", executionEngine);
			namedParameterJdbcTemplate.query(executionEngineParam, params, rowMapper);
		} catch (Exception e) {
			logger.error(e.toString());
		}
		return result;
	}

	public Map<String, String> getHadoopEngineGlobalParam(String hadoopEngine, String scriptEngine){
		Map<String, String> resultMap = new HashMap<String, String>();
		try {
			TwoColumnRowMapper rowMapper = new TwoColumnRowMapper();
			rowMapper.setResultMap(resultMap);
			rowMapper.setFirstColumnName("parameter");
			rowMapper.setSecondColumnName("value");
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(getJdbcTemplate());
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("hadoopEngine", hadoopEngine);
			params.put("scriptEngine", scriptEngine);
			namedParameterJdbcTemplate.query(hadoopEngineParam, params, rowMapper);
		} catch (Exception e) {
			logger.error(e.toString());
		}
		return resultMap;
	}
}
