package com.walgreens.dae.constans;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.LogManager;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
/**
 * This is a utility class for doing various functions.
 * @author 		MOHIT SINGH
 * @version 	0.1
 * @since		2016-05-01
 */
@Component
public class Utils {
	
	@Value(value = "${ssh.username}")
	private String sshUserName;
	@Value(value = "${ssh.password}")
	private String sshPassword;
	@Value(value = "${ssh.port}")
	private String sshport;
	@Value(value = "${ssh.host}")
	private String sshhost;

	/**
	 * This function is used to change the log file name and path based on project name and job name.
	 * If log path is not updated then the default path is used. It creates the log path {logpath}/{projectname}/{jobname}/{date}
	 * @param project name
	 * @param job name
	 */
	public void setLogPath(String project, String job) { 
		Properties props = new Properties(); 
		try { 
			InputStream configStream = getClass().getResourceAsStream( "/log4j.properties"); 
			props.load(configStream); 
			configStream.close(); 
		} catch (IOException e) { 
			System.out.println("Error not laod configuration file "); 
		} catch (Exception e) {
			System.out.println();
		}
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String filename = props.getProperty("log4j.appender.file.File");
		filename = filename.replace("{project}", project);
		filename = filename.replace("{job}", job);
		filename = filename.replace("{date}", sdf.format(date));

		props.setProperty("log4j.appender.file.File", filename); 
		LogManager.resetConfiguration(); 
		PropertyConfigurator.configure(props); 
	}

	/**
	 * This method is used to create a SSH session on UNIX machine.
	 * @return com.jcraft.jsch.Session
	 */
	public Session getUnixSession() {
		JSch js = new JSch();
		Session s = null;
		try {
			s = js.getSession(sshUserName, sshhost, Integer.valueOf(sshport).intValue());
		} catch (JSchException e) {
			e.printStackTrace();
		}
		s.setPassword(sshPassword);
		Properties config = new Properties();
		config.put("StrictHostKeyChecking", "no");
		s.setConfig(config);
		try {
			s.connect();
		} catch (JSchException e) {
			e.printStackTrace();
		}
		return s;
	}

	/**
	 * This method is used to collect the HADOOP application id's from the logs.
	 * @param line
	 * @return Set<String>
	 */
	public static Set<String> getJobId(String line) {
		Set<String> result = new HashSet<String>();
		String regex = "application_\\w*";
		Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(line);
		while (matcher.find()) {
			result.add((matcher.group()).toString());
		}
		return result;
	}

}
