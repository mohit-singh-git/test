package com.walgreens.dae.constans;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

@Component
public class Utils {
	
	 public void setLogPath(String project, String job) { 
		    Properties props = new Properties(); 
		    try { 
		        InputStream configStream = getClass().getResourceAsStream( "/log4j.properties"); 
		        props.load(configStream); 
		        configStream.close(); 
		    } catch (IOException e) { 
		        System.out.println("Errornot laod configuration file "); 
		    } catch (Exception e) {
		    	System.out.println();
		    }
		    Date date = new Date();
		    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		    String filename = props.getProperty("log4j.appender.file.File");
		    filename = filename.replace("{project}", project);
		    filename = filename.replace("{job}", job);
		    filename = filename.replace("{date}", sdf.format(date));
		    
		    props.setProperty("log4j.appender.file.File", filename); 
		    LogManager.resetConfiguration(); 
		    PropertyConfigurator.configure(props); 
		 }

	 public Session getUnixSession() {
		 	JSch js = new JSch();
		    Session s = null;
			try {
				s = js.getSession("hdfs", "localhost", 2222);
			} catch (JSchException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    s.setPassword("hdfs");
		    Properties config = new Properties();
		    config.put("StrictHostKeyChecking", "no");
		    s.setConfig(config);
		    try {
				s.connect();
			} catch (JSchException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    return s;
	 }
	 
	 public static Set<String> getJobId(String line) {
		 Set<String> result = new HashSet<String>();
		 String regex = "application_\\w*";
		 Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		 Matcher matcher = pattern.matcher(line);
		 while (matcher.find()) {
			 result.add((matcher.group()).toString());
		 }
		 return result;
	 }
	 
}
