package com.walgreens.dae.process.subprocess;

import java.io.IOException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walgreens.dae.dao.DAEMetadataDAO;

@Component
public class SetUpEnvVariablesProcess {
	@Autowired
	DAEMetadataDAO dAEMetadataDAO;
	
	
	public void execute(String projectName, String jobName) {
		Map<String, String> result = getJobENVData(projectName, jobName);
		Process p;
		for(Map.Entry<String, String> env : result.entrySet()) {
			String command = "export "+ env.getKey()+"="+ env.getValue();
			try {
				p = Runtime.getRuntime().exec(command);
				p.waitFor();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Map<String, String> getJobENVData(String projectName, String jobName) {
		Map<String, String> result = dAEMetadataDAO.getEnvVar(projectName, jobName);
		return result;
	}
}
