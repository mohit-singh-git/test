package com.walgreens.dae.process.subprocess;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.walgreens.dae.bean.JobParameterBean;
import com.walgreens.dae.dao.DAEMetadataDAO;

@Component
public class AfterJobProcess {

	@Autowired
	DAEMetadataDAO dAEMetadataDAO;

	Logger logger = Logger.getLogger(AfterJobProcess.class);
	public void execute(JobParameterBean jobParameterBean,String projectName, String jobName, String Status) {
			dAEMetadataDAO.updateJobStatus(projectName, jobName, jobParameterBean.getBatchId(),Status);	
			for (String jobId : jobParameterBean.getHadoopJobIds()) {
				Session s = jobParameterBean.getSession();
				Channel c;
				try {
					c = s.openChannel("exec");
					ChannelExec ce = (ChannelExec) c;
					ce.setCommand("curl -XGET 'http://localhost:8088/ws/v1/cluster/apps/'"+jobId);
					ce.setErrStream(System.err);
					ce.connect();

					BufferedReader stdInput = new BufferedReader(new InputStreamReader(ce.getInputStream()));
					BufferedReader stdError = new BufferedReader(new InputStreamReader(ce.getErrStream()));
					String inputline="";
					String errorline="";
					while ((inputline = stdInput.readLine()) != null || (errorline = stdError.readLine()) != null) {
						if (inputline != null && inputline != "") {
							logger.info(inputline);
						}if (errorline != null && errorline != ""){
							logger.info(errorline); 
						}
					}					    
					logger.info("Exit code: " + ce.getExitStatus());
					jobParameterBean.setExitCode(ce.getExitStatus());
					ce.disconnect();
				} catch (JSchException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} 
			}
	}
}
