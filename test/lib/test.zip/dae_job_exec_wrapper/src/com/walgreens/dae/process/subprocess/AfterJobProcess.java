package com.walgreens.dae.process.subprocess;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walgreens.dae.bean.JobParameterBean;
import com.walgreens.dae.dao.DAEMetadataDAO;

@Component
public class AfterJobProcess {

	@Autowired
	DAEMetadataDAO dAEMetadataDAO;

	final static Logger logger = Logger.getLogger(AfterJobProcess.class);
	public void execute(JobParameterBean jobParameterBean,String projectName, String jobName, String Status) {
			dAEMetadataDAO.updateJobStatus(projectName, jobName, jobParameterBean.getBatchId(),Status);		
	}
}
