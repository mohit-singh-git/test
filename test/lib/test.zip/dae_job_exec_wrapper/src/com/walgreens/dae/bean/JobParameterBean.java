package com.walgreens.dae.bean;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.jcraft.jsch.Session;

public class JobParameterBean {

	private Session session;
	private int exitCode;
	private String batchId;
	private Map<String,Map<String,Map<String,String>>> jobparam;
	private Map<String,Map<String,String>> executionFrameworkGlobalParam;
	private Map<String,String> hadoopEngineParam;
	private Set<String> hadoopJobIds = new HashSet<String>();
	
	public Set<String> getHadoopJobIds() {
		return hadoopJobIds;
	}
	public void setHadoopJobIds(Set<String> hadoopJobIds) {
		this.hadoopJobIds = hadoopJobIds;
	}
	public Map<String, String> getHadoopEngineParam() {
		return hadoopEngineParam;
	}
	public void setHadoopEngineParam(Map<String, String> hadoopEngineParam) {
		this.hadoopEngineParam = hadoopEngineParam;
	}
	public String getBatchId() {
		return batchId;
	}
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}
	public Map<String, Map<String, Map<String, String>>> getJobparam() {
		return jobparam;
	}
	public void setJobparam(Map<String, Map<String, Map<String, String>>> jobparam) {
		this.jobparam = jobparam;
	}
	public Map<String, Map<String, String>> getExecutionFrameworkGlobalParam() {
		return executionFrameworkGlobalParam;
	}
	public void setExecutionFrameworkGlobalParam(Map<String, Map<String, String>> executionFrameworkGlobalParam) {
		this.executionFrameworkGlobalParam = executionFrameworkGlobalParam;
	}
	public int getExitCode() {
		return exitCode;
	}
	public void setExitCode(int exitCode) {
		this.exitCode = exitCode;
	}
	public Session getSession() {
		return session;
	}
	public void setSession(Session session) {
		this.session = session;
	}
	
}
