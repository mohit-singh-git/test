package com.walgreens.dae.bean;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.jcraft.jsch.Session;

/**
 * This is a bean class for storing job parameters. This class is used by subprocess.
 * @author 		MOHIT SINGH
 * @version 	0.1
 * @since		2016-05-01
 */
public class JobParameterBean {

	
	/** A UNIX session created by JSCH java API. */
	private Session session;
	
	/**	This is the exit code returned by the SSH shell. */
	private int exitCode;
	
	/**	This is EDW batch id that will be used to execute a batch. */
	private String batchId;
	
	/** This map contains job parameters. The value is parameter->sub parameter->key,value. */
	private Map<String,Map<String,Map<String,String>>> jobparam;
	
	/** This map contains global parameters for execution framework(OOZIE,FALCON, etc.). 
	 * The values are framework name -> parameter,value.
	 */
	private Map<String,Map<String,String>> executionFrameworkGlobalParam;
	
	/** This map contains global parameters for processing engine (mr,tez,spark) in key,value pair. */
	private Map<String,String> hadoopEngineParam;
	
	/** This hash set contains all the application id created by yarn for a job. These application id is used to get the 
	 *  job information like start time,end time,CPU and memory used for a job
	 */
	private Set<String> hadoopJobIds = new HashSet<String>();
	
	
	public Set<String> getHadoopJobIds() {
		return hadoopJobIds;
	}
	public void setHadoopJobIds(Set<String> hadoopJobIds) {
		this.hadoopJobIds = hadoopJobIds;
	}
	public Map<String, String> getHadoopEngineParam() {
		return hadoopEngineParam;
	}
	public void setHadoopEngineParam(Map<String, String> hadoopEngineParam) {
		this.hadoopEngineParam = hadoopEngineParam;
	}
	public String getBatchId() {
		return batchId;
	}
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}
	public Map<String, Map<String, Map<String, String>>> getJobparam() {
		return jobparam;
	}
	public void setJobparam(Map<String, Map<String, Map<String, String>>> jobparam) {
		this.jobparam = jobparam;
	}
	public Map<String, Map<String, String>> getExecutionFrameworkGlobalParam() {
		return executionFrameworkGlobalParam;
	}
	public void setExecutionFrameworkGlobalParam(Map<String, Map<String, String>> executionFrameworkGlobalParam) {
		this.executionFrameworkGlobalParam = executionFrameworkGlobalParam;
	}
	public int getExitCode() {
		return exitCode;
	}
	public void setExitCode(int exitCode) {
		this.exitCode = exitCode;
	}
	public Session getSession() {
		return session;
	}
	public void setSession(Session session) {
		this.session = session;
	}
	
}
