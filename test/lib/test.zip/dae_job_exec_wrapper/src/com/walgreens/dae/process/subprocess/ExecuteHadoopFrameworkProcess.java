package com.walgreens.dae.process.subprocess;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.oozie.client.OozieClient;
import org.apache.oozie.client.WorkflowJob.Status;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.walgreens.dae.bean.JobParameterBean;
import com.walgreens.dae.constans.Utils;


@Component
public class ExecuteHadoopFrameworkProcess {

	static final Logger logger = Logger.getLogger(ExecuteHadoopFrameworkProcess.class);

	public void execute(JobParameterBean jobParameterBean) throws JSchException, IOException {

		Map<String, String> paramMap = new HashMap<String, String>();
		String executionFramework = "";
		Set<String> scriptType = null;;
		Map<String, String> processingEngineMap = null;

		if (jobParameterBean.getJobparam().containsKey("engine")) {

			if (jobParameterBean.getJobparam().get("engine").containsKey("processingEngine")) {
				processingEngineMap = jobParameterBean.getJobparam().get("engine").get("processingEngine");
			}

			if (jobParameterBean.getJobparam().get("engine").containsKey("executionFramework")) {
				Map<String, String> executionFrameworkMap = jobParameterBean.getJobparam().get("engine").get("executionFramework");
				executionFramework = String.valueOf(executionFrameworkMap.keySet().toArray()[0]);
				if (jobParameterBean.getJobparam().get("engine").containsKey("scriptType")) {
					Map<String, String> scriptTypeMap = jobParameterBean.getJobparam().get("engine").get("scriptType");
					for (Map.Entry<String, String> entry : scriptTypeMap.entrySet()) {
						scriptType = new HashSet<String>();
						scriptType.add(entry.getKey());
					}
				}
			} else if (jobParameterBean.getJobparam().get("engine").containsKey("scriptType")) {
				Map<String, String> scriptTypeMap = jobParameterBean.getJobparam().get("engine").get("scriptType");
				for (Map.Entry<String, String> entry : scriptTypeMap.entrySet()) {
					scriptType = new HashSet<String>();
					scriptType.add(entry.getKey());
				}
			}

		}

		if (executionFramework != "") {
			paramMap.putAll(jobParameterBean.getExecutionFrameworkGlobalParam().get(executionFramework));
		}
		if (scriptType != null && !scriptType.isEmpty()) {
			for (String scriptEngine : scriptType) {
				if (jobParameterBean.getExecutionFrameworkGlobalParam().get(scriptEngine) != null) {
				paramMap.putAll(jobParameterBean.getExecutionFrameworkGlobalParam().get(scriptEngine));
				}
			}
		}
		if (processingEngineMap != null && !processingEngineMap.isEmpty()) {
			paramMap.putAll(processingEngineMap);
		}
		if (jobParameterBean.getJobparam() != null && !jobParameterBean.getJobparam().isEmpty()) {
			for (Map.Entry<String, Map<String,Map<String,String>>> entry : jobParameterBean.getJobparam().entrySet()) {
				for (Map.Entry<String, Map<String, String>> entry2 : entry.getValue().entrySet()) {
					paramMap.putAll(entry2.getValue());
				}
			}
		}

		if (executionFramework != "") {
			if (executionFramework.equals("oozie")) {
			OozieClient wc = new OozieClient(jobParameterBean.getExecutionFrameworkGlobalParam().get("oozie").get("oozieUrl"));
			Properties conf = wc.createConfiguration();
			for (Map.Entry<String, String> param : paramMap.entrySet()) {
				conf.setProperty(param.getKey(), param.getValue());
			}

			try {
				String jobId = wc.run(conf);
				while (wc.getJobInfo(jobId).getStatus() == Status.RUNNING) {
					Thread.sleep(10 * 1000);
				}
				System.out.println("Workflow job completed ...");
				System.out.println(wc.getJobInfo(jobId));
			} catch (Exception r) {
				System.out.println("Errors " + r.getLocalizedMessage());
			}} else if (executionFramework.equals("falcon")) {
				
			}
		} else {
			if (scriptType != null && !scriptType.isEmpty()) {
				String script = scriptType.toArray()[0].toString();
				if (script.equals("pig")) {
					StringBuilder builder = new StringBuilder();
					builder.append("pig ");
					for (Map.Entry<String, String> entry : paramMap.entrySet()) {
						builder.append("-param "+entry.getKey()+"="+entry.getValue());
					}
					builder.append("-f " + paramMap.get("pigScript"));
				 	Session s = jobParameterBean.getSession();
				    Channel c = s.openChannel("exec");
				    ChannelExec ce = (ChannelExec) c;
				    ce.setCommand(builder.toString());
				    ce.setErrStream(System.err);
				    ce.connect();
				    BufferedReader stdInput = new BufferedReader(new InputStreamReader(ce.getInputStream()));
				    BufferedReader stdError = new BufferedReader(new InputStreamReader(ce.getErrStream()));
				    String inputline="";
				    String errorline="";
				    while ((inputline = stdInput.readLine()) != null || (errorline = stdError.readLine()) != null) {
				      if (inputline != null && inputline != "") {
				    	  jobParameterBean.getHadoopJobIds().addAll(Utils.getJobId(inputline));
				    	  logger.info(inputline);
				      }if (errorline != null && errorline != ""){
				    	  jobParameterBean.getHadoopJobIds().addAll(Utils.getJobId(errorline));
				    	  logger.info(errorline); 
				      }
				    }					    
				    logger.info("Exit code: " + ce.getExitStatus());
				    jobParameterBean.setExitCode(ce.getExitStatus());
				    ce.disconnect();

			

				} else if (script.equals("hive")) {
						// Create a Hive shell command
						// Sample : Hive -hiveconf table=prescription -hiveconf database=target -f script.hql
						StringBuilder builder = new StringBuilder();
						builder.append("Hive ");
						for (Map.Entry<String, String> entry : paramMap.entrySet()) {
							builder.append("-hiveconf "+entry.getKey()+"="+entry.getValue());
						}
						builder.append("-f " + paramMap.get("hiveScript"));
						
						// get the SSH session already created on edge node. This session will be having KERBEROS token.
					 	Session s = jobParameterBean.getSession();
					    Channel c = s.openChannel("exec");
					    ChannelExec ce = (ChannelExec) c;
					    ce.setCommand(builder.toString());
					    ce.setErrStream(System.err);
					    // Execute the shell command from edge node.
					    ce.connect();
					    BufferedReader stdInput = new BufferedReader(new InputStreamReader(ce.getInputStream()));
					    BufferedReader stdError = new BufferedReader(new InputStreamReader(ce.getErrStream()));
					    String inputline="";
					    String errorline="";
					    
					    // redirect the console messages to Log file
					    while ((inputline = stdInput.readLine()) != null || (errorline = stdError.readLine()) != null) {
					      if (inputline != null && inputline != "") {
					    	  // Collect Yarn application ID
					    	  jobParameterBean.getHadoopJobIds().addAll(Utils.getJobId(inputline));
					    	  logger.info(inputline);
					      }if (errorline != null && errorline != ""){
					    	  jobParameterBean.getHadoopJobIds().addAll(Utils.getJobId(errorline));
					    	  logger.info(errorline); 
					      }
					    }					    
					    logger.info("Exit code: " + ce.getExitStatus());
					    // Set the job exit status. So that appropriate action can be taken based on job status in subsequent process.
					    jobParameterBean.setExitCode(ce.getExitStatus());
					    // Disconnect the channel
					    ce.disconnect();

				} else if (script.equals("shell")) {

					StringBuilder builder = new StringBuilder();
					for (Map.Entry<String, String> entry : paramMap.entrySet()) {
						builder.append(entry.getKey()+"="+entry.getValue());
					}
					builder.append(" ." + paramMap.get("shellScript"));
				 	Session s = jobParameterBean.getSession();
				    Channel c = s.openChannel("exec");
				    ChannelExec ce = (ChannelExec) c;
				    ce.setCommand(builder.toString());
				    ce.setErrStream(System.err);
				    ce.connect();
				    BufferedReader stdInput = new BufferedReader(new InputStreamReader(ce.getInputStream()));
				    BufferedReader stdError = new BufferedReader(new InputStreamReader(ce.getErrStream()));
				    String inputline="";
				    String errorline="";
				    while ((inputline = stdInput.readLine()) != null || (errorline = stdError.readLine()) != null) {
				      if (inputline != null && inputline != "") {
				    	  jobParameterBean.getHadoopJobIds().addAll(Utils.getJobId(inputline));
				    	  logger.info(inputline);
				      }if (errorline != null && errorline != ""){
				    	  jobParameterBean.getHadoopJobIds().addAll(Utils.getJobId(errorline));
				    	  logger.info(errorline); 
				      }
				    }					    
				    logger.info("Exit code: " + ce.getExitStatus());
				    jobParameterBean.setExitCode(ce.getExitStatus());
				    ce.disconnect();

				} 
			}
		}
	}
}
