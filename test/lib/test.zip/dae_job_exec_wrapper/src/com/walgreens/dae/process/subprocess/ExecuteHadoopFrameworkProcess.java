package com.walgreens.dae.process.subprocess;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.walgreens.dae.bean.JobParameterBean;


@Component
public class ExecuteHadoopFrameworkProcess {

	final static Logger logger = Logger.getLogger(BeforeJobProcess.class);

	public void execute(JobParameterBean jobParameterBean) {

		Map<String, String> paramMap = new HashMap<String, String>();
		String executionFramework = "";
		Set<String> scriptType = null;;
		Map<String, String> processingEngineMap = null;

		if (jobParameterBean.getJobparam().containsKey("engine")) {

			if (jobParameterBean.getJobparam().get("engine").containsKey("processingEngine")) {
				processingEngineMap = jobParameterBean.getJobparam().get("engine").get("processingEngine");
			}

			if (jobParameterBean.getJobparam().get("engine").containsKey("executionFramework")) {
				Map<String, String> executionFrameworkMap = jobParameterBean.getJobparam().get("engine").get("executionFramework");
				executionFramework = String.valueOf(executionFrameworkMap.keySet().toArray()[0]);
				if (jobParameterBean.getJobparam().get("engine").containsKey("scriptType")) {
					Map<String, String> scriptTypeMap = jobParameterBean.getJobparam().get("engine").get("scriptType");
					for (Map.Entry<String, String> entry : scriptTypeMap.entrySet()) {
						scriptType = new HashSet<String>();
						scriptType.add(entry.getKey());
					}
				}
			} else if (jobParameterBean.getJobparam().get("engine").containsKey("scriptType")) {
				Map<String, String> scriptTypeMap = jobParameterBean.getJobparam().get("engine").get("scriptType");
				for (Map.Entry<String, String> entry : scriptTypeMap.entrySet()) {
					scriptType = new HashSet<String>();
					scriptType.add(entry.getKey());
				}
			}

		}

		//create map for global as well as framework parameters
		if (executionFramework != "") {
			paramMap.putAll(jobParameterBean.getExecutionFrameworkGlobalParam().get(executionFramework));
		}
		if (scriptType != null && !scriptType.isEmpty()) {
			for (String scriptEngine : scriptType) {
				if (jobParameterBean.getExecutionFrameworkGlobalParam().get(scriptEngine) != null) {
				paramMap.putAll(jobParameterBean.getExecutionFrameworkGlobalParam().get(scriptEngine));
				}
			}
		}
		if (processingEngineMap != null && !processingEngineMap.isEmpty()) {
			paramMap.putAll(processingEngineMap);
		}
		if (jobParameterBean.getJobparam() != null && !jobParameterBean.getJobparam().isEmpty()) {
			for (Map.Entry<String, Map<String,Map<String,String>>> entry : jobParameterBean.getJobparam().entrySet()) {
				for (Map.Entry<String, Map<String, String>> entry2 : entry.getValue().entrySet()) {
					paramMap.putAll(entry2.getValue());
				}
			}
		}

		//----------------------Framework Execution-----------------------------

		if (executionFramework != "") {
			if (executionFramework.equals("oozie")) {
				String filePath = paramMap.get("oozieJobProperties");
				List<String> lines = new ArrayList<String>();
				File file = new File(filePath);
				for (Map.Entry<String, String> entry : paramMap.entrySet()) {
					lines.add(entry.getKey()+"="+entry.getValue());
				}
				try {
					FileUtils.writeLines(file, lines, true);
				} catch (IOException e) {
					e.printStackTrace();
				}
				String command = "oozie job -oozie "+paramMap.get("oozieUrl")+ " -config " +file.getAbsolutePath();
				Process p;
				try {
					p = Runtime.getRuntime().exec(command);
					try {
						p.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
					BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
					logger.info(stdInput.toString());
					logger.error(stdError.toString());
					jobParameterBean.setExitCode(p.exitValue());
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else if (executionFramework.equals("falcon")) {

			}
		} else {
			if (scriptType != null && scriptType.isEmpty()) {
				String script = scriptType.toArray()[0].toString();
				if (script.equals("pig")) {

				} else if (script.equals("hive")) {

				} else if (script.equals("sqoop")) {

				} else if (script.equals("mr")) {

				} else if (script.equals("shell")) {

				} else if (script.equals("java")) {

				} else if (script.equals("python")) {

				} else if (script.equals("flume")) {

				}
			}
		}


	}
}
