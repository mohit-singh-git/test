package com.walgreens.dae.process.wrapper;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.JSchException;
import com.walgreens.dae.bean.JobParameterBean;
import com.walgreens.dae.constans.Utils;
import com.walgreens.dae.process.subprocess.AfterJobProcess;
import com.walgreens.dae.process.subprocess.AuditProcess;
import com.walgreens.dae.process.subprocess.BeforeJobProcess;
import com.walgreens.dae.process.subprocess.ExecuteHadoopFrameworkProcess;
import com.walgreens.dae.process.subprocess.JobExitProcess;
import com.walgreens.dae.process.subprocess.SetUpBatchParamProcess;
import com.walgreens.dae.process.subprocess.SetUpEnvVariablesProcess;

@Component
public class DAEJobExecWrapperMain {

	@Autowired
	SetUpEnvVariablesProcess setUpEnvVariablesProcess;
	@Autowired
	SetUpBatchParamProcess setUpBatchParamProcess;
	@Autowired
	JobExitProcess jobExitProcess;
	@Autowired
	ExecuteHadoopFrameworkProcess executeHadoopFrameworkProcess;
	@Autowired
	BeforeJobProcess beforeJobProcess;
	@Autowired
	AuditProcess auditProcess;
	@Autowired
	AfterJobProcess afterJobProcess;
	@Autowired
	Utils utils;


	private String projectName="rx";
	private String jobName="prescription_log_transfer";

	final static Logger logger = Logger.getLogger(DAEJobExecWrapperMain.class);

	public static void main(String args[]) {
		ApplicationContext context;
		try {
			context = new ClassPathXmlApplicationContext("application-context.xml");
			DAEJobExecWrapperMain daeJobExecWrapperMain = (DAEJobExecWrapperMain)context.getBean("DAEJobExecWrapperMain");
			daeJobExecWrapperMain.execute();
		} catch (Exception e) {

		} 
	}

	public void execute() {

		utils.setLogPath(getProjectName(), getJobName());
		JobParameterBean jobParameterBean = new JobParameterBean();
		jobParameterBean.setSession(utils.getUnixSession());
		setUpEnvVariablesProcess.execute(getProjectName(), getJobName());
		setUpBatchParamProcess.execute(projectName, jobName, jobParameterBean);
		auditProcess.execute(jobParameterBean);
		beforeJobProcess.execute(jobParameterBean, projectName, jobName);
		try {
			executeHadoopFrameworkProcess.execute(jobParameterBean);
		} catch (JSchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		afterJobProcess.execute(jobParameterBean, projectName, jobName, String.valueOf(jobParameterBean.getExitCode()));
		jobExitProcess.execute(jobParameterBean);

	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
}
