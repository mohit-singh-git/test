package com.walgreens.dae.process.wrapper;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.walgreens.dae.bean.JobParameterBean;
import com.walgreens.dae.process.subprocess.AfterJobProcess;
import com.walgreens.dae.process.subprocess.AuditProcess;
import com.walgreens.dae.process.subprocess.BeforeJobProcess;
import com.walgreens.dae.process.subprocess.ExecuteHadoopFrameworkProcess;
import com.walgreens.dae.process.subprocess.JobExitProcess;
import com.walgreens.dae.process.subprocess.SetUpBatchParamProcess;
import com.walgreens.dae.process.subprocess.SetUpEnvVariablesProcess;

@Component
public class DAEJobExecWrapperMain {
	
	@Autowired
	SetUpEnvVariablesProcess setUpEnvVariablesProcess;
	@Autowired
	SetUpBatchParamProcess setUpBatchParamProcess;
	@Autowired
	JobExitProcess jobExitProcess;
	@Autowired
	ExecuteHadoopFrameworkProcess executeHadoopFrameworkProcess;
	@Autowired
	BeforeJobProcess beforeJobProcess;
	@Autowired
	AuditProcess auditProcess;
	@Autowired
	AfterJobProcess afterJobProcess;
	
	
	final static Logger logger = Logger.getLogger(DAEJobExecWrapperMain.class);
	private String projectName="rx";
	private String jobName="prescription_log_transfer";
	
	public static void main(String args[]) {
		ApplicationContext context;
		try {
		logger.info("Starting DAEJobExecWrapperMain process");
		context = new ClassPathXmlApplicationContext("application-context.xml");
		DAEJobExecWrapperMain daeJobExecWrapperMain = (DAEJobExecWrapperMain)context.getBean("DAEJobExecWrapperMain");;
		daeJobExecWrapperMain.execute();
		} catch (Exception e) {
			
		} 
	}
	
	public void execute() {
		JobParameterBean jobParameterBean = new JobParameterBean();
		
		setUpEnvVariablesProcess.execute(getProjectName(), getJobName());
		setUpBatchParamProcess.execute(projectName, jobName, jobParameterBean);
		auditProcess.execute(jobParameterBean);
		beforeJobProcess.execute(jobParameterBean, projectName, jobName);
		executeHadoopFrameworkProcess.execute(jobParameterBean);
		afterJobProcess.execute(jobParameterBean, projectName, jobName, String.valueOf(jobParameterBean.getExitCode()));
		jobExitProcess.execute(jobParameterBean);
		
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
}
