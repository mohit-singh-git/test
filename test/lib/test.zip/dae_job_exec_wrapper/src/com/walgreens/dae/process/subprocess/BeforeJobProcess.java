package com.walgreens.dae.process.subprocess;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.walgreens.dae.bean.JobParameterBean;
import com.walgreens.dae.dao.DAEMetadataDAO;
@Component
public class BeforeJobProcess {

	@Autowired
	DAEMetadataDAO dAEMetadataDAO;

	final static Logger logger = Logger.getLogger(BeforeJobProcess.class);
	public void execute(JobParameterBean jobParameterBean,String projectName, String jobName) {
		Map<String, String> result = dAEMetadataDAO.getJobRunSeqAndStatus(projectName, jobName, jobParameterBean.getBatchId());
		if (result.containsKey("status")) {
			if (result.get("status").equals("Completed")) {
				logger.info("Job already completed: skipping");
				System.exit(0);
			} else if (result.get("status").equals("failed")){
				int lastRunSeq = Integer.parseInt(result.get("seq_number"));
				if (jobParameterBean.getJobparam().containsKey("execution")) {
					if (jobParameterBean.getJobparam().get("execution").containsKey("executionFailure")) {
						if (jobParameterBean.getJobparam().get("execution").get("executionFailure").containsKey("maxRetry")) {
							int maxRetry = Integer.parseInt(jobParameterBean.getJobparam().get("execution").
									get("executionFailure").get("maxRetry"));
							if (lastRunSeq < maxRetry) {
								lastRunSeq++;
								dAEMetadataDAO.updateJobRunSeqAndStatus(projectName, jobName, 
										jobParameterBean.getBatchId(),lastRunSeq) ;
							}
						}
					}
				}
			} else if (result.get("status").equals("0")){
				int lastRunSeq = Integer.parseInt(result.get("seq_number"));
				lastRunSeq++;
				dAEMetadataDAO.updateJobRunSeqAndStatus(projectName, jobName, 
						jobParameterBean.getBatchId(),lastRunSeq) ;
			}
		}
	}
}
