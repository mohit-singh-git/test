package com.walgreens.dae.data.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;

public class ThreeColumnRowMapper implements RowMapper<Object> {
	
	private String firstColumnName = "";
	private String secondColumnName = "";
	private String thirdColumnName = "";
	
	
	Map<String,Map<String,String>> result= null;

	public Map<String, Map<String, String>> getResult() {
		return result;
	}

	public void setResult(Map<String, Map<String, String>> result) {
		this.result = result;
	}

	@Override
	public Object mapRow(ResultSet rs, int row) throws SQLException {
		if (rs != null) {
			String paramType = rs.getString(getFirstColumnName());
			String key = rs.getString(getSecondColumnName());
			String value = rs.getString(getThirdColumnName());
			if (getResult().containsKey(paramType)) {
					getResult().get(paramType).put(key, value);
				}
			else {
				Map<String,String> keyValueMap = new HashMap<String,String>();
				keyValueMap.put(key, value);
				getResult().put(paramType, keyValueMap);
			}
			} 
		return null;
	}

	public String getFirstColumnName() {
		return firstColumnName;
	}

	public void setFirstColumnName(String firstColumnName) {
		this.firstColumnName = firstColumnName;
	}

	public String getSecondColumnName() {
		return secondColumnName;
	}

	public void setSecondColumnName(String secondColumnName) {
		this.secondColumnName = secondColumnName;
	}

	public String getThirdColumnName() {
		return thirdColumnName;
	}

	public void setThirdColumnName(String thirdColumnName) {
		this.thirdColumnName = thirdColumnName;
	}

}
